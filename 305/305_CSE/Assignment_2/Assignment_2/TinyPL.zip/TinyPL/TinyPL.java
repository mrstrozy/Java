public class TinyPL {
		
	public static void main(String args[]) {   
		   Lexer.lex();
		   new Program();  
	}
}

class Program {
	 
}

class Decls {
	 
}

class Idlist {
	 
}

class Stmts {
	 
}

class Stmt {
	 
} 

class Assign {
	 
}

class Cond  {
	 
}

class Loop {

}

class Cmpd  {
	 
}


class Expr {  
	 
}

class Term {  

}


class Factor {  
	 
}

class Literal {
	 
}

class Int_Lit extends Literal {
	 
	
}

class Real_Lit extends Literal {
	 
	
}

class Bool_Lit extends Literal {
	 
	
}

class Id_Lit extends Literal {

	
}

